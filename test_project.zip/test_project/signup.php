<?php

include_once 'header.php';

?>

<body class="singup_body">

<section class="s-form">

   <form action="includes/signup.inc.php" method="$_POST">

      <h3>SIGNUP</h3><br><br>

      
         <div class="input-group">
            <input type="text" id="name" name="name" required>
            <label for="name"><i class="fa-solid fa-user"></i> Full Name</label>
         </div><br><br>
      
         
         <div class="input-group">
         <input type="email" id="email" name="email" required>
         <label for="email"><i class="fa-solid fa-envelope"></i> E-mail</label>
      </div><br><br>

      
         <div class="input-group">
            <input type="text" id="uid" name="uid" required>
            <label for="uid"><i class="fa-solid fa-user"></i> Username</label>
         </div>
       <br><br>

   
      <div class="input-group">
         <input type="password" id="pwd" name="pwd" required>
         <label for="pwd"><i class="fa-solid fa-key"></i> Password</label>
      </div><br><br>
   
      <div class="input-group">
         <input type="password" id="pwdrepeat" name="pwdrepeat" required>
         <label for="pwdrepeat"><i class="fa-solid fa-key"></i> Repeat your password</label>
      </div><br>
   
   

      <button type="submit" name="submit">Register</button>
   
   </form>

   <?php

   if(isset($_GET["error"])){
      if($_GET["error"] == "emptyinput"){
         echo "<p>Fill in all fields!</p>";
      }
      else if($_GET["error"] == "invaliduid"){
         echo "<p>Choose a proper username!</p>";
      }
      else if($_GET["error"] == "invalidemail"){
         echo "<p>Choose a proper email!</p>";
      }
      else if($_GET["error"] == "passworddontmatch"){
         echo "<p>Password doesn't match!</p>";
      }
      else if($_GET["error"] == "stmtfailed"){
         echo "<p>Something went wrong, try again!</p>";
      }
      else if($_GET["error"] == "usernametaken"){
         echo "<p>Username already taken!</p>";
      }
      else if($_GET["error"] == "none"){
         echo "<p>You have signed up!</p>";
      }

   }
   

   ?>
</section>


</body>

<script src="https://kit.fontawesome.com/615de15e92.js" crossorigin="anonymous"></script>

<?php

include_once 'footer.php';

?>