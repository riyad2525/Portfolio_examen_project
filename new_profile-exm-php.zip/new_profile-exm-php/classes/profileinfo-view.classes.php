<?php

class ProfileInfoView extends ProfileInfo{
   
}