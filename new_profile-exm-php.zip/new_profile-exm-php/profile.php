<?php
   session_start();
   include_once 'header.php';
?>


<div class="profile">
   <div class="profile-bg">
      <div class="profile-wrapper">
         <div class="profile-info">
         <div class="profile-info-img">
            <p>
           
            </p>
            <a href="profilesettings.php" class="follow-btn">PROFILE SETTINGS</a>
         </div>
         <div class="profile-info-about">
            <h3>ABOUT</h3>
            <p>

            </p>
            <h3>FOLLOWERS</h3>
         </div>
         </div>  
         <div class="profile-content">
            <div class="profile-intro">
               <h3>

               </h3>
               <p>
              
               </p>
            </div>
            <div class="profile-posts">
               <h3>POST</h3>
               <div class="profile-post">
                  <h2>MOTION SENSOR</h2>
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quia, natus.</p>
               </div>
            </div>
         </div>       
      </div>
   </div>
</div>


<?php
   include_once 'footer.php';
?>
