 <!-- footer Start-->
 <footer class="footer-main">

<div class="wrapper-main footer-main-flex">

<div class="footer-testemoni">
   <img src="img/portret/prt-1.png" alt="testemoni" style="size: 50px;">
   <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit.
   </p>
</div>
<div class="footer-testemoni">
   <img src="img/portret/prt-2.png" alt="testemoni">
   <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit.
   </p>
</div>
<div class="footer-testemoni">
   <img src="img/portret/prt-3.png" alt="testemoni">
   <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit.
   </p>
</div>
<div class="footer-testemoni">
   <img src="img/portret/prt-4.png" alt="testemoni">
   <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit.
   </p>
</div>

<div class="footer-sitemap">
   <ul>
      <li><a href="#">HOME</a></li>
      <li><a href="#">ABOUT US</a></li>
      <li><a href="#">CONTACT</a></li>
   </ul>
   <ul>
      <li><a href="#">project-1</a></li>
      <li><a href="#">project-2</a></li>
      <li><a href="#">project-3</a></li>
      <li><a href="#">project-4</a></li>
   </ul>
   <ul>
      <li><p>GET IN TOUCH:</p></li>
      <li><p>+31205893472</p></li>
      <li><p>r.alameen@yahoo.com</p></li>
      <li><p>plantkoninglaan 50 3198 JE Bloemendaal</p></li>
   </ul>
</div>
</div>
</footer>
<!-- footer End-->
</div>
</body>
</html>