<?php

$serverName = "localhost";
$dBUsername = "root";
$dBUpassword = "";
$dBName = "pfproject";

$conn = mysqli_connect($serverName, $dBUsername, $dBUpassword, $dBName);

if (!$conn) {

   die ("connection failed:" . mysqli_connect_error());
}