 <!-- footer Start-->
 <footer class="footer-main">

<div class="wrapper-main footer-main-flex">

<div class="footer-testemoni">
   <img src="img/portret/prt-1.png" alt="testemoni" style="size: 50px;">
   <p>
   It was amazing... I never experienced this before!
   </p>
</div>
<div class="footer-testemoni">
   <img src="img/portret/prt-2.png" alt="testemoni">
   <p>
   I will love to see more sensors on this site.   </p>
</div>
<div class="footer-testemoni">
   <img src="img/portret/prt-3.png" alt="testemoni">
   <p>
   Wow... That profile system is fantastic!
   </p>
</div>
<div class="footer-testemoni">
   <img src="img/portret/prt-4.png" alt="testemoni">
   <p>
   I really recommend this site to explore more.
   </p>
</div>

<div class="footer-sitemap">
   <ul>
      <li><a href="index.php">HOME</a></li>
      <li><a href="sensors.php">SENSORS</a></li></li>
      <li><a href="profile.php">PROFILE</a></li>
   </ul>
   <ul>
      <li><a href="#">project-1</a></li>
      <li><a href="#">project-2</a></li>
      <li><a href="#">project-3</a></li>
      <li><a href="#">project-4</a></li>
   </ul>
   <ul>
      <li><p>GET IN TOUCH:</p></li>
      <li><p>+31235310883</p></li>
      <li><p>info@rebox.tv</p></li>
      <li><p>Hendrik Figeeweg 1x 2031 BJ Haarlem</p></li>
   </ul>
</div>
</div>
</footer>
<!-- footer End-->
</div>
</body>
</html>